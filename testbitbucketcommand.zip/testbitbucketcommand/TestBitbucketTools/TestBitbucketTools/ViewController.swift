//
//  ViewController.swift
//  TestBitbucketTools
//
//  Created by kaushal kishor on 08/04/22.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    // switched to feature/test-repo
    

  }

  @IBAction func nextClicked(_ sender: UIButton) {
    let vc = self.storyboard?.instantiateViewController(withIdentifier: "FirstVC") as! FirstVC
    let navController = UINavigationController.init(rootViewController: vc)
    navController.modalPresentationStyle = .fullScreen
    //navController.modalTransitionStyle = .crossDissolve

    self.present(navController, animated: true) {
    }
  }
  
}

